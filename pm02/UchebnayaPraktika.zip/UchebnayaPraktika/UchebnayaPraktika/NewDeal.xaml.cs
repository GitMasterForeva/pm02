﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UchebnayaPraktika
{
    /// <summary>
    /// Логика взаимодействия для NewDeal.xaml
    /// </summary>
    public partial class NewDeal : Window
    {
        public NewDeal()
        {
            InitializeComponent();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void AddNewDealButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем значения из TextBox'ов
            int realEstateID;
            int clientID;
            int agentID;
            DateTime dealDate;
            double dealPrice;

            // Проверяем, что все значения корректны
            bool isRealEstateIDValid = int.TryParse(RealEstateIDTextBox.Text, out realEstateID);
            bool isClientIDValid = int.TryParse(ClientIDTextBox.Text, out clientID);
            bool isAgentIDValid = int.TryParse(AgentIDTextBox.Text, out agentID);
            bool isDealDateValid = DateTime.TryParse(DealDateTextBox.Text, out dealDate);
            bool isDealPriceValid = double.TryParse(DealPriceTextBox.Text, out dealPrice);

            // Проверяем, что все данные корректны
            if (!isRealEstateIDValid || !isClientIDValid || !isAgentIDValid || !isDealDateValid || !isDealPriceValid)
            {
                MessageBox.Show("Пожалуйста, убедитесь, что все поля заполнены корректно.");
                return; // Прерываем выполнение, если хотя бы одно значение некорректно
            }

            // Строка подключения
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=1234;Database=pm02";

            // SQL-запрос для вставки данных в таблицу Deals
            string query = "INSERT INTO pm02.Deals (RealEstateID, ClientID, AgentID, DealDate, DealPrice) " +
                           "VALUES (@RealEstateID, @ClientID, @AgentID, @DealDate, @DealPrice)";

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        // Параметры для предотвращения SQL-инъекций
                        command.Parameters.AddWithValue("@RealEstateID", realEstateID);
                        command.Parameters.AddWithValue("@ClientID", clientID);
                        command.Parameters.AddWithValue("@AgentID", agentID);
                        command.Parameters.AddWithValue("@DealDate", dealDate);
                        command.Parameters.AddWithValue("@DealPrice", dealPrice);

                        // Выполняем запрос
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Сделка успешна добавлена!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}
