﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UchebnayaPraktika
{
    /// <summary>
    /// Логика взаимодействия для NewAgent.xaml
    /// </summary>
    public partial class NewAgent : Window
    {
        public NewAgent()
        {
            InitializeComponent();
        }

        private void AddNewAgentButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем значения из TextBox'ов
            string fullName = FullNameTextBox.Text;
            string phoneNumber = PhoneNumberTextBox.Text;
            string email = EmailTextBox.Text;
            double commissionRate;

            // Проверяем, что поле CommissionRate корректно
            bool isCommissionRateValid = double.TryParse(CommissionRateTextBox.Text, out commissionRate);

            // Проверяем, что все данные корректны
            if (string.IsNullOrEmpty(fullName) || string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(email) || !isCommissionRateValid)
            {
                MessageBox.Show("Пожалуйста, убедитесь, что все поля заполнены корректно.");
                return; // Прерываем выполнение, если хотя бы одно значение некорректно
            }

            // Строка подключения
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=1234;Database=pm02";

            // SQL-запрос для вставки данных в таблицу Agents
            string query = "INSERT INTO pm02.Agents (FullName, PhoneNumber, Email, CommissionRate) " +
                           "VALUES (@FullName, @PhoneNumber, @Email, @CommissionRate)";

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        // Параметры для предотвращения SQL-инъекций
                        command.Parameters.AddWithValue("@FullName", fullName);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@CommissionRate", commissionRate);

                        // Выполняем запрос
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Агент успешно добавлен!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
