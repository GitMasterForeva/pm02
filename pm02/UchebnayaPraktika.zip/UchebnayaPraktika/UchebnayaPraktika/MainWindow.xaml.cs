﻿using System;
using System.Windows;
using Npgsql;
using System.Collections.ObjectModel;
using Microsoft.Win32;
using System.Collections.Generic;
using System.IO;
using System.Data;
using System.IO.Compression;


namespace UchebnayaPraktika
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Agent> Agents { get; set; }
        public ObservableCollection<Category> Categories { get; set; }
        public ObservableCollection<Client> Clients { get; set; }
        public ObservableCollection<Deal> Deals { get; set; }
        public ObservableCollection<Owner> Owners { get; set; }
        public ObservableCollection<RealEstate> RealEstates { get; set; }

        private int _currentTableIndex = 0;

        private readonly string[] _tables = new string[] {
            "pm02.agents",
            "pm02.categories",
            "pm02.clients",
            "pm02.deals",
            "pm02.owners",
            "pm02.realestate"
        };

        public MainWindow()
        {
            InitializeComponent();
            Agents = new ObservableCollection<Agent>();
            Categories = new ObservableCollection<Category>();
            Clients = new ObservableCollection<Client>();
            Deals = new ObservableCollection<Deal>();
            Owners = new ObservableCollection<Owner>();
            RealEstates = new ObservableCollection<RealEstate>();
            this.DataContext = this;
            LoadData();
        }

        private void LoadData()
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=1234;Database=pm02";
            string query = GetQueryForTable(_tables[_currentTableIndex]);

            switch (_currentTableIndex)
            {
                case 0: Agents.Clear(); break;
                case 1: Categories.Clear(); break;
                case 2: Clients.Clear(); break;
                case 3: Deals.Clear(); break;
                case 4: Owners.Clear(); break;
                case 5: RealEstates.Clear(); break;
            }

            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();
                using (var cmd = new NpgsqlCommand(query, connection))
                {
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (_currentTableIndex == 0)
                            {
                                Agents.Add(new Agent
                                {
                                    AgentID = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                                    FullName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    PhoneNumber = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                    Email = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                                    CommissionRate = reader.IsDBNull(4) ? 0 : reader.GetDouble(4)
                                });
                                DataGrid1.ItemsSource = Agents;
                                TableNameLabel.Content = "Название таблицы: Агенты недвижимости.";
                            }
                            else if (_currentTableIndex == 1)
                            {
                                Categories.Add(new Category
                                {
                                    CategoryID = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                                    Name = reader.IsDBNull(1) ? string.Empty : reader.GetString(1)
                                });
                                DataGrid1.ItemsSource = Categories;
                                TableNameLabel.Content = "Название таблицы: Категории недвижимости.";
                            }
                            else if (_currentTableIndex == 2)
                            {
                                Clients.Add(new Client
                                {
                                    ClientID = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                                    FullName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    PhoneNumber = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                    Email = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                                    PreferredCategory = reader.IsDBNull(4) ? string.Empty : reader.GetString(4),
                                    Budget = reader.IsDBNull(5) ? 0 : reader.GetDouble(5)
                                });
                                DataGrid1.ItemsSource = Clients;
                                TableNameLabel.Content = "Название таблицы: Клиенты";
                            }
                            else if (_currentTableIndex == 3)
                            {
                                Deals.Add(new Deal
                                {
                                    DealID = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                                    RealEstateID = reader.IsDBNull(1) ? 0 : reader.GetInt32(1),
                                    ClientID = reader.IsDBNull(2) ? 0 : reader.GetInt32(2),
                                    AgentID = reader.IsDBNull(3) ? 0 : reader.GetInt32(3),
                                    DealDate = reader.IsDBNull(4) ? DateTime.MinValue : reader.GetDateTime(4),
                                    DealPrice = reader.IsDBNull(5) ? 0 : reader.GetDouble(5)
                                });
                                DataGrid1.ItemsSource = Deals;
                                TableNameLabel.Content = "Название таблицы: Сделки";
                            }
                            else if (_currentTableIndex == 4)
                            {
                                Owners.Add(new Owner
                                {
                                    OwnerID = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                                    FullName = reader.IsDBNull(1) ? string.Empty : reader.GetString(1),
                                    PhoneNumber = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                    Email = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                                    Address = reader.IsDBNull(4) ? string.Empty : reader.GetString(4)
                                });
                                DataGrid1.ItemsSource = Owners;
                                TableNameLabel.Content = "Название таблицы: Собвстенники";
                            }
                            else if (_currentTableIndex == 5)
                            {
                                RealEstates.Add(new RealEstate
                                {
                                    RealEstateID = reader.IsDBNull(0) ? 0 : reader.GetInt32(0),
                                    OwnerID = reader.IsDBNull(1) ? 0 : reader.GetInt32(1),
                                    Category = reader.IsDBNull(2) ? string.Empty : reader.GetString(2),
                                    Address = reader.IsDBNull(3) ? string.Empty : reader.GetString(3),
                                    Area = reader.IsDBNull(4) ? 0 : reader.GetDouble(4),
                                    Price = reader.IsDBNull(5) ? 0 : reader.GetDouble(5),
                                    Description = reader.IsDBNull(6) ? string.Empty : reader.GetString(6)
                                });
                                DataGrid1.ItemsSource = RealEstates;
                                TableNameLabel.Content = "Название таблицы: Объекты недвижимости.";
                            }
                        }
                    }
                }
            }
            DataGrid1.Items.Refresh();
        }

        private string GetQueryForTable(string table)
        {
            if (table == "pm02.agents")
            {
                return "SELECT AgentID, FullName, PhoneNumber, Email, CommissionRate FROM pm02.agents";
            }
            else if (table == "pm02.categories")
            {
                return "SELECT CategoryID, Name FROM pm02.categories";
            }
            else if (table == "pm02.clients")
            {
                return "SELECT ClientID, FullName, PhoneNumber, Email, PreferredCategory, Budget FROM pm02.clients";
            }
            else if (table == "pm02.deals")
            {
                return "SELECT DealID, RealEstateID, ClientID, AgentID, DealDate, DealPrice FROM pm02.deals";
            }
            else if (table == "pm02.owners")
            {
                return "SELECT OwnerID, FullName, PhoneNumber, Email, Address FROM pm02.owners";
            }
            else if (table == "pm02.realestate")
            {
                return "SELECT RealEstateID, OwnerID, Category, Address, Area, Price, Description FROM pm02.realestate";
            }
            else
            {
                throw new ArgumentException("Неизвестная таблица");
            }
        }

        private void PreviousButton_Click(object sender, RoutedEventArgs e)
        {
            _currentTableIndex = (_currentTableIndex - 1 + _tables.Length) % _tables.Length;
            LoadData();
            DataGrid1.Items.Refresh();
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            _currentTableIndex = (_currentTableIndex + 1) % _tables.Length;
            LoadData();
            DataGrid1.Items.Refresh();
        }
        

        private void DeleteLineButton_Click(object sender, RoutedEventArgs e)
        {
            SecondWindow secondWindow = new SecondWindow();
            secondWindow.DeleteLineEvent += DeleteLine;
            secondWindow.ShowDialog();
            DataGrid1.Items.Refresh();
        }

        private void DeleteLine(int id)
        {
            string columnName = GetColumnNameForCurrentTable();
            string tableName = GetTableNameForCurrentIndex();

            DeleteFromDatabase(columnName, id, tableName);
            DataGrid1.Items.Refresh();
        }

        private string GetColumnNameForCurrentTable()
        {
            switch (_currentTableIndex)
            {
                case 0: return "AgentID";
                case 1: return "CategoryID";
                case 2: return "ClientID";
                case 3: return "DealID";
                case 4: return "OwnerID";
                case 5: return "RealEstateID";
                default: return null;
            }
        }

        private string GetTableNameForCurrentIndex()
        {
            switch (_currentTableIndex)
            {
                case 0: return "Agents";
                case 1: return "Categories";
                case 2: return "Clients";
                case 3: return "Deals";
                case 4: return "Owners";
                case 5: return "RealEstates";
                default: return null;
            }
        }

        private void DeleteFromDatabase(string columnName, int id, string tableName)
        {
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=1234;Database=pm02";;
            using (var connection = new NpgsqlConnection(connectionString))
            {
                connection.Open();

                string deleteQuery = $"DELETE FROM pm02.{tableName} WHERE {columnName} = @id";
                using (var command = new NpgsqlCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    try
                    {
                        command.ExecuteNonQuery();
                        MessageBox.Show("Запись успешно удалена!");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка удаления записи: {ex.Message}");
                    }
                }
            }
            DataGrid1.Items.Refresh();
        }

        private void MenuItemNewCategory_Click(object sender, RoutedEventArgs e)
        {
            NewCategory newCategory = new NewCategory();
            newCategory.ShowDialog();
        }

        private void MenuItemNewRealEstate_Click(object sender, RoutedEventArgs e)
        {
            NewRealEstate newRealEstate = new NewRealEstate();
            newRealEstate.ShowDialog();
        }

        private void MenuItemNewAgent_Click(object sender, RoutedEventArgs e)
        {
            NewAgent newAgent = new NewAgent();
            newAgent.ShowDialog();
        }

        private void MenuItemNewClient_Click(object sender, RoutedEventArgs e)
        {
            NewClient newClient = new NewClient();
            newClient.ShowDialog();
        }

        private void MenuItemNewDeal_Click(object sender, RoutedEventArgs e)
        {
            NewDeal newDeal = new NewDeal();
            newDeal.ShowDialog();
        }

        private void MenuItemNewOwner_Click(object sender, RoutedEventArgs e)
        {
            NewOwner newOwner = new NewOwner();
            newOwner.ShowDialog();
        }

        private void MenuItemSaveTable_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "CSV files (*.csv)|*.csv|All files (*.*)|*.*";

            if (saveFileDialog.ShowDialog() == true)
            {
                string filePath = saveFileDialog.FileName;

                try
                {
                    SaveTableToCSV(filePath, _currentTableIndex);

                    MessageBox.Show("Данные успешно сохранены!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении файла: {ex.Message}");
                }
            }
        }

        private void SaveTableToCSV(string filePath, int tableIndex)
        {
            var lines = new List<string>();

            switch (tableIndex)
            {
                case 0:
                    lines.Add("AgentID,FullName,PhoneNumber,Email,CommissionRate");
                    foreach (var agent in Agents)
                    {
                        lines.Add($"{agent.AgentID},{agent.FullName},{agent.PhoneNumber},{agent.Email},{agent.CommissionRate}");
                    }
                    break;

                case 1:
                    lines.Add("CategoryID,Name");
                    foreach (var category in Categories)
                    {
                        lines.Add($"{category.CategoryID},{category.Name}");
                    }
                    break;

                case 2:
                    lines.Add("ClientID,FullName,PhoneNumber,Email,PreferredCategory,Budget");
                    foreach (var client in Clients)
                    {
                        lines.Add($"{client.ClientID},{client.FullName},{client.PhoneNumber},{client.Email},{client.PreferredCategory},{client.Budget}");
                    }
                    break;

                case 3:
                    lines.Add("DealID,RealEstateID,ClientID,AgentID,DealDate,DealPrice");
                    foreach (var deal in Deals)
                    {
                        lines.Add($"{deal.DealID},{deal.RealEstateID},{deal.ClientID},{deal.AgentID},{deal.DealDate:yyyy-MM-dd},{deal.DealPrice}");
                    }
                    break;

                case 4:
                    lines.Add("OwnerID,FullName,PhoneNumber,Email,Address");
                    foreach (var owner in Owners)
                    {
                        lines.Add($"{owner.OwnerID},{owner.FullName},{owner.PhoneNumber},{owner.Email},{owner.Address}");
                    }
                    break;

                case 5:
                    lines.Add("RealEstateID,OwnerID,Category,Address,Area,Price,Description");
                    foreach (var realEstate in RealEstates)
                    {
                        lines.Add($"{realEstate.RealEstateID},{realEstate.OwnerID},{realEstate.Category},{realEstate.Address},{realEstate.Area},{realEstate.Price},{realEstate.Description}");
                    }
                    break;

                default:
                    throw new Exception("Неизвестная таблица.");
            }

            File.WriteAllLines(filePath, lines);
        }

        private void MenuItemDB_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=1234;Database=pm02";
                string tempFolder = Path.Combine(Path.GetTempPath(), "DatabaseExport");
                if (Directory.Exists(tempFolder))
                    Directory.Delete(tempFolder, true);
                Directory.CreateDirectory(tempFolder);

                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();
                    DataTable tables = connection.GetSchema("Tables", new string[] { null, "pm02" });

                    foreach (DataRow row in tables.Rows)
                    {
                        string tableName = row["table_name"].ToString();
                        string csvFilePath = Path.Combine(tempFolder, $"{tableName}.csv");

                        using (var cmd = new NpgsqlCommand($"SELECT * FROM pm02.{tableName}", connection))
                        using (var reader = cmd.ExecuteReader())
                        using (var writer = new StreamWriter(csvFilePath))
                        {
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                if (i > 0) writer.Write(",");
                                writer.Write(reader.GetName(i));
                            }
                            writer.WriteLine();

                            while (reader.Read())
                            {
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    if (i > 0) writer.Write(",");
                                    writer.Write(reader.GetValue(i).ToString());
                                }
                                writer.WriteLine();
                            }
                        }
                    }
                }
                string zipFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "DatabaseExport.zip");
                if (File.Exists(zipFilePath))
                    File.Delete(zipFilePath);

                ZipFile.CreateFromDirectory(tempFolder, zipFilePath);

                MessageBox.Show("Экспорт БД выполнен. Файл был сохранён.", "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);

                Directory.Delete(tempFolder, true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MenuItemUserInfo_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItemChangeUser_Click(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItemExit_Click(object sender, RoutedEventArgs e)
        {

        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
            DataGrid1.Items.Refresh();
        }
    }

    public class Agent
    {
        public int AgentID { get; set; }
        public string FullName { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public double CommissionRate { get; set; }
    }

    public class Category
    {
        public int CategoryID { get; set; }
        public string Name { get; set; }
    }

    public class Client
    {
        public int ClientID { get; set; }
        public string FullName { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string PreferredCategory { get; set; }
        public double Budget { get; set; }
    }

    public class Deal
    {
        public int DealID { get; set; }
        public int RealEstateID { get; set; }
        public int ClientID { get; set; }
        public int AgentID { get; set; }
        public DateTime DealDate { get; set; }
        public double DealPrice { get; set; }
    }

    public class Owner
    {
        public int OwnerID { get; set; }
        public string FullName { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string Address { get; set; }
    }

    public class RealEstate
    {
        public int RealEstateID { get; set; }
        public int OwnerID { get; set; }
        public string Category { get; set; }
        public string Address { get; set; }
        public double Area { get; set; }
        public double Price { get; set; }
        public string Description { get; set; }
    }

}
