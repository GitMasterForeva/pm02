﻿using System;
using System.Windows;
using Npgsql;

namespace UchebnayaPraktika
{
    /// <summary>
    /// Логика взаимодействия для NewOwner.xaml
    /// </summary>
    public partial class NewOwner : Window
    {
        public NewOwner()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void AddNewOwnerButton_Click(object sender, RoutedEventArgs e)
        {
            string fullName = FullNameTextBox.Text;
            string phoneNumber = PhoneNumberTextBox.Text;
            string email = EmailTextBox.Text;
            string address = AddressTextBox.Text;

            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=1234;Database=pm02";

            string query = "INSERT INTO pm02.Owners (FullName, PhoneNumber, Email, Address) " +
                           "VALUES (@FullName, @PhoneNumber, @Email, @Address)";
            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@FullName", fullName);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@Address", address);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Собственник успешно добавлен!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}
