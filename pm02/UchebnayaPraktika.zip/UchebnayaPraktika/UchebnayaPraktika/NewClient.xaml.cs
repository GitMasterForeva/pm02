﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UchebnayaPraktika
{
    /// <summary>
    /// Логика взаимодействия для NewClient.xaml
    /// </summary>
    public partial class NewClient : Window
    {
        public NewClient()
        {
            InitializeComponent();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void AddNewClientButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем значения из TextBox'ов
            string fullName = FullNameTextBox.Text;
            string phoneNumber = PhoneNumberTextBox.Text;
            string email = EmailTextBox.Text;
            string preferredCategory = PreferredCategoryTextBox.Text;

            // Пытаемся преобразовать бюджет в число
            double budget;
            bool isBudgetValid = double.TryParse(BudgetTextBox.Text, out budget);

            // Проверяем, был ли ввод корректным
            if (!isBudgetValid)
            {
                MessageBox.Show("Пожалуйста, введите корректное значение для бюджета.");
                return; // Прерываем выполнение, если ввод некорректен
            }

            // Строка подключения
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=1234;Database=pm02";

            // SQL-запрос для вставки данных в таблицу Clients
            string query = "INSERT INTO pm02.Clients (FullName, PhoneNumber, Email, PreferredCategory, Budget) " +
                           "VALUES (@FullName, @PhoneNumber, @Email, @PreferredCategory, @Budget)";

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        // Параметры для предотвращения SQL-инъекций
                        command.Parameters.AddWithValue("@FullName", fullName);
                        command.Parameters.AddWithValue("@PhoneNumber", phoneNumber);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@PreferredCategory", preferredCategory);
                        command.Parameters.AddWithValue("@Budget", budget);

                        // Выполняем запрос
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Клиент успешно добавлен!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}
