﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UchebnayaPraktika
{
    /// <summary>
    /// Логика взаимодействия для NewRealEstate.xaml
    /// </summary>
    public partial class NewRealEstate : Window
    {
        public NewRealEstate()
        {
            InitializeComponent();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void AddNewRealEstate_Click(object sender, RoutedEventArgs e)
        {
            // Получаем значения из TextBox'ов
            int ownerID;
            string category = CategoryTextBox.Text;
            string address = AddressTextBox.Text;
            double area;
            double price;

            // Проверяем, что все значения корректны
            bool isOwnerIDValid = int.TryParse(OwnerIDTextBox.Text, out ownerID);
            bool isAreaValid = double.TryParse(AreaTextBox.Text, out area);
            bool isPriceValid = double.TryParse(PriceTextBox.Text, out price);

            // Проверяем, что все данные корректны
            if (!isOwnerIDValid || string.IsNullOrEmpty(category) || string.IsNullOrEmpty(address) || !isAreaValid || !isPriceValid)
            {
                MessageBox.Show("Пожалуйста, убедитесь, что все поля заполнены корректно.");
                return; // Прерываем выполнение, если хотя бы одно значение некорректно
            }

            // Строка подключения
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=1234;Database=pm02";

            // SQL-запрос для вставки данных в таблицу RealEstate
            string query = "INSERT INTO pm02.RealEstate (OwnerID, Category, Address, Area, Price) " +
                           "VALUES (@OwnerID, @Category, @Address, @Area, @Price)";

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        // Параметры для предотвращения SQL-инъекций
                        command.Parameters.AddWithValue("@OwnerID", ownerID);
                        command.Parameters.AddWithValue("@Category", category);
                        command.Parameters.AddWithValue("@Address", address);
                        command.Parameters.AddWithValue("@Area", area);
                        command.Parameters.AddWithValue("@Price", price);

                        // Выполняем запрос
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Недвижимость успешно добавлена!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}
