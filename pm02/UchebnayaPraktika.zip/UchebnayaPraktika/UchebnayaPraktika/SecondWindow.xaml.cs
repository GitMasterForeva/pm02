﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UchebnayaPraktika
{
    /// <summary>
    /// Логика взаимодействия для SecondWindow.xaml
    /// </summary>
    public partial class SecondWindow : Window
    {
        public SecondWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        public delegate void DeleteLineEventHandler(int ID);
        public event DeleteLineEventHandler DeleteLineEvent;
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            if (int.TryParse(DeleteLineTextBox.Text, out int ID))
            {
                DeleteLineEvent?.Invoke(ID);
                this.Close();
            }
            else 
            {
                MessageBox.Show("Введите действительный ID.");
            }
        }
    }
}
