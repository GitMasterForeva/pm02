﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace UchebnayaPraktika
{
    /// <summary>
    /// Логика взаимодействия для NewCategory.xaml
    /// </summary>
    public partial class NewCategory : Window
    {
        public NewCategory()
        {
            InitializeComponent();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void AddNewCategoryButton_Click(object sender, RoutedEventArgs e)
        {
            // Получаем значения из TextBox'ов
            string name = NameTextBox.Text;

            // Строка подключения
            string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=1234;Database=pm02";

            // SQL-запрос для вставки данных в таблицу Categories
            string query = "INSERT INTO pm02.Categories (Name) VALUES (@Name)";

            try
            {
                using (var connection = new NpgsqlConnection(connectionString))
                {
                    connection.Open();

                    using (var command = new NpgsqlCommand(query, connection))
                    {
                        // Параметры для предотвращения SQL-инъекций
                        command.Parameters.AddWithValue("@Name", name);

                        // Выполняем запрос
                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Новая категрия недвижимости успешно добавлена!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    }
}
