package pm02;

public class NazarovNM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int age = 18;
		System.out.print("Юлиана ");
		System.out.println("18");
		System.out.println("Лена " + age);

	}

}
